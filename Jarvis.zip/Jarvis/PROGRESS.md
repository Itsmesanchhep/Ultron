# JARVIS progress

All of this is written but NOT yet tested on a device.

Included: HUD interface, Gemini/Claude provider switch, speech-to-text, text-to-speech with interrupt,
tool system (open app, flashlight, alarm, timer, volume, brightness, Do Not Disturb, settings shortcuts,
call/SMS drafts, calendar event drafts, read notifications, battery, time), confirmation for sensitive tools,
memory you control, activity history, pause button, quick-access notification, Quick Settings tile,
translucent voice overlay, logo.

Not included (by design or not feasible): wake word, default-assistant role, accessibility screen control,
file management, direct toggling of Wi-Fi/Bluetooth (blocked by Android), secure backend proxy.

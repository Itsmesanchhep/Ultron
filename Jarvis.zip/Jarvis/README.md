# JARVIS (milestone 1)

Build: push to GitHub, open the Actions tab, run "Build APK", download the `jarvis-debug-apk` artifact.
See PROGRESS.md for status.

package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val role: String, val text: String) // role: "user" or "assistant"

/** Any AI provider implements this, so providers can be swapped later. */
interface AiProvider {
    suspend fun chat(history: List<ChatMessage>, system: String): String
}

private fun httpPost(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
    val conn = URL(url).openConnection() as HttpURLConnection
    try {
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return code to (stream?.bufferedReader()?.use { it.readText() } ?: "")
    } finally {
        conn.disconnect()
    }
}

class ClaudeProvider(
    private val apiKey: () -> String,
    private val endpoint: () -> String,
    private val model: String = "claude-sonnet-5-5"
) : AiProvider {

    override suspend fun chat(history: List<ChatMessage>, system: String): String = withContext(Dispatchers.IO) {
        val key = apiKey()
        val url = endpoint()
        if (key.isBlank() && url == SecurePrefs.DEFAULT_ENDPOINT) {
            throw IOException("No API key set. Open Settings and paste your key.")
        }
        val msgs = JSONArray()
        history.takeLast(20).dropWhile { it.role != "user" }.forEach {
            msgs.put(JSONObject().put("role", it.role).put("content", it.text))
        }
        val body = JSONObject()
            .put("model", model).put("max_tokens", 600)
            .put("system", system).put("messages", msgs)
        val headers = mutableMapOf("anthropic-version" to "2023-06-01")
        if (key.isNotBlank()) headers["x-api-key"] = key
        val (code, text) = httpPost(url, headers, body)
        if (code !in 200..299) throw IOException("API error $code: $text")
        val content = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        sb.toString().trim()
    }
}

class GeminiProvider(
    private val apiKey: () -> String,
    private val model: () -> String
) : AiProvider {

    override suspend fun chat(history: List<ChatMessage>, system: String): String = withContext(Dispatchers.IO) {
        val key = apiKey()
        if (key.isBlank()) throw IOException("No Gemini key set. Open Settings and paste your key.")

        val contents = JSONArray()
        history.takeLast(20).dropWhile { it.role != "user" }.forEach {
            contents.put(
                JSONObject()
                    .put("role", if (it.role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }

        fun body(withSearch: Boolean): JSONObject {
            val b = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 700))
            // Google Search grounding gives live answers (weather, news, research)
            if (withSearch) b.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            return b
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${model().trim()}:generateContent"
        val headers = mapOf("x-goog-api-key" to key)
        var r = httpPost(url, headers, body(true))
        if (r.first !in 200..299) r = httpPost(url, headers, body(false)) // retry without search
        val (code, text) = r
        if (code == 404) throw IOException("Model '${model()}' not found. Change the model name in Settings (try gemini-2.5-flash).")
        if (code !in 200..299) throw IOException("API error $code: $text")

        val cands = JSONObject(text).optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw IOException("Gemini returned no answer: $text")
        val parts = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        sb.toString().trim()
    }
}

/** Picks the provider chosen in Settings each time a question is asked. */
class SwitchingProvider(private val prefs: SecurePrefs) : AiProvider {
    override suspend fun chat(history: List<ChatMessage>, system: String): String =
        if (prefs.provider == "claude")
            ClaudeProvider({ prefs.apiKey }, { prefs.endpoint }).chat(history, system)
        else
            GeminiProvider({ prefs.geminiKey }, { prefs.geminiModel }).chat(history, system)
}

package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val XPanel = Color(0xFF0B1A2C)
private val XCyan = Color(0xFF3DDCFF)
private val XText = Color(0xFFE8F4FF)
private val XDim = Color(0xFF7C93AB)
private val XMint = Color(0xFF5CF2C0)
private val XAmber = Color(0xFFFFB84D)

fun accentFor(status: Status, paused: Boolean): Color = when {
    paused -> XDim
    status == Status.LISTENING -> XMint
    status == Status.THINKING -> XAmber
    else -> XCyan
}

/** Asks for a runtime permission when a tool needs one (contacts, etc.), then retries the command. */
@Composable
fun PermissionHost(vm: JarvisViewModel) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.onPermissionResult(it) }
    val req = vm.permissionRequest
    LaunchedEffect(req) { if (req != null) launcher.launch(req) }
}

@Composable
fun ConfirmCard(vm: JarvisViewModel) {
    val p = vm.pending ?: return
    Column(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).background(XPanel, RoundedCornerShape(12.dp)).padding(12.dp)
    ) {
        Text(p.prompt, color = XText, fontSize = 14.sp)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.confirmPending(true) }) { Text("Confirm") }
            OutlinedButton(onClick = { vm.confirmPending(false) }) { Text("Cancel") }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = XCyan, fontSize = 13.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun QuickAccessSection(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(vm.prefs.quickAccess) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { vm.prefs.quickAccess = true; on = true; QuickAccess.show(ctx) }
    }
    SectionTitle("USE JARVIS FROM ANY SCREEN")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Quick-access notification", color = XText)
        Switch(checked = on, onCheckedChange = { want ->
            if (want) {
                val needs = Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                if (needs) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else { vm.prefs.quickAccess = true; on = true; QuickAccess.show(ctx) }
            } else {
                vm.prefs.quickAccess = false; on = false; QuickAccess.hide(ctx)
            }
        })
    }
    Text(
        "Shows a notification with a Speak button. Tap it from any app and JARVIS listens in a small overlay. " +
            "You can also add the JARVIS tile: swipe down twice, tap the edit (pencil) icon, and drag JARVIS into your active tiles.",
        color = XDim, fontSize = 13.sp
    )
}

@Composable
fun AccessSection() {
    val ctx = LocalContext.current
    fun open(intent: Intent) {
        try { ctx.startActivity(intent) } catch (_: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    SectionTitle("OPTIONAL ACCESS")
    Text("Each one is optional, off by default, and can be revoked in Android settings at any time.", color = XDim, fontSize = 13.sp)

    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Notification access", color = XText)
        Text("Lets JARVIS read your notifications aloud when you ask. The text stays on your phone and is never sent to the AI.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("Open settings") }
    }
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Modify system settings", color = XText)
        Text("Needed only to change screen brightness by voice.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = {
            open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        }) { Text("Open settings") }
    }
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Do Not Disturb access", color = XText)
        Text("Needed only to turn Do Not Disturb on or off by voice.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) { Text("Open settings") }
    }
    Column(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(12.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Honor battery settings", color = XText)
        Text("Honor may close JARVIS in the background. In Settings > Apps > App launch, set JARVIS to manage manually and allow background activity.", color = XDim, fontSize = 13.sp)
        OutlinedButton(onClick = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery optimization") }
    }
    Text("Contacts permission is requested only when you ask JARVIS to call or text someone by name.", color = XDim, fontSize = 13.sp)
}

@Composable
fun MemorySection(vm: JarvisViewModel) {
    SectionTitle("MEMORY")
    Text(
        "Only things you ask JARVIS to remember (say \"remember that...\"). They are stored encrypted on this phone and sent to the AI as context with your questions.",
        color = XDim, fontSize = 13.sp
    )
    if (vm.memories.isEmpty()) Text("Nothing saved.", color = XDim, fontSize = 13.sp)
    vm.memories.forEachIndexed { i, m ->
        Row(Modifier.fillMaxWidth().background(XPanel, RoundedCornerShape(10.dp)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(m, color = XText, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("  ✕", color = XAmber, modifier = Modifier.clickable { vm.deleteMemory(i) }.padding(8.dp))
        }
    }
    if (vm.memories.isNotEmpty()) OutlinedButton(onClick = { vm.clearMemories() }) { Text("Delete all memory") }
}

@Composable
fun ActivitySection(vm: JarvisViewModel) {
    SectionTitle("ACTIVITY HISTORY")
    if (vm.actionLog.isEmpty()) Text("No phone actions yet.", color = XDim, fontSize = 13.sp)
    vm.actionLog.takeLast(15).reversed().forEach {
        Text(it, color = XDim, fontSize = 12.sp)
    }
    if (vm.actionLog.isNotEmpty()) OutlinedButton(onClick = { vm.clearActionLog() }) { Text("Clear history") }
}

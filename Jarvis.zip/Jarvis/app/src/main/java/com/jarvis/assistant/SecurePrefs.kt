package com.jarvis.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores settings (including the API key) encrypted on the device. */
class SecurePrefs(context: Context) {

    private val sp: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "jarvis_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null // falls back to memory-only for this session
    }
    private val mem = HashMap<String, Any>()

    private fun str(k: String, d: String): String =
        if (sp != null) (sp.getString(k, d) ?: d) else ((mem[k] as? String) ?: d)

    private fun putStr(k: String, v: String) {
        if (sp != null) sp.edit().putString(k, v).apply() else mem[k] = v
    }

    private fun bool(k: String, d: Boolean): Boolean =
        if (sp != null) sp.getBoolean(k, d) else ((mem[k] as? Boolean) ?: d)

    private fun putBool(k: String, v: Boolean) {
        if (sp != null) sp.edit().putBoolean(k, v).apply() else mem[k] = v
    }

    private fun flt(k: String, d: Float): Float =
        if (sp != null) sp.getFloat(k, d) else ((mem[k] as? Float) ?: d)

    private fun putFlt(k: String, v: Float) {
        if (sp != null) sp.edit().putFloat(k, v).apply() else mem[k] = v
    }

    var apiKey: String
        get() = str("api_key", "")
        set(v) = putStr("api_key", v)

    var provider: String
        get() = str("provider", "gemini")
        set(v) = putStr("provider", v)

    var geminiKey: String
        get() = str("gemini_key", "")
        set(v) = putStr("gemini_key", v)

    var geminiModel: String
        get() = str("gemini_model", DEFAULT_GEMINI_MODEL)
        set(v) = putStr("gemini_model", v)

    var memoryRaw: String
        get() = str("memory", "")
        set(v) = putStr("memory", v)

    var logRaw: String
        get() = str("actionlog", "")
        set(v) = putStr("actionlog", v)

    var quickAccess: Boolean
        get() = bool("quick", false)
        set(v) = putBool("quick", v)

    var endpoint: String
        get() = str("endpoint", DEFAULT_ENDPOINT)
        set(v) = putStr("endpoint", v)

    var speakReplies: Boolean
        get() = bool("speak", true)
        set(v) = putBool("speak", v)

    var speechRate: Float
        get() = flt("rate", 1.0f)
        set(v) = putFlt("rate", v)

    companion object {
        const val DEFAULT_ENDPOINT = "https://api.anthropic.com/v1/messages"
        const val DEFAULT_GEMINI_MODEL = "gemini-3.5-flash"
    }
}

package com.jarvis.assistant

import android.content.Context
import org.json.JSONObject

data class ToolResult(val message: String, val permission: String? = null)
data class ToolCall(val name: String, val args: JSONObject, val say: String = "")
class ToolSpec(
    val name: String,
    val usage: String,
    val sensitive: Boolean,
    val run: (Context, JSONObject) -> ToolResult
)

/** The only things JARVIS can do. The AI picks from this list; it can never run arbitrary code. */
class ToolRouter(private val onRemember: (String) -> Unit, private val onForgetAll: () -> Unit) {

    val tools: List<ToolSpec> = listOf(
        ToolSpec("open_app", """{"name":"app name"}""", false) { c, a -> ToolResult(AppLauncherTool.run(c, a.optString("name"))) },
        ToolSpec("flashlight", """{"on":true}""", false) { c, a -> ToolResult(FlashlightTool.run(c, a.optBoolean("on", true))) },
        ToolSpec("set_alarm", """{"hour":0-23,"minute":0-59,"label":"text"}""", false) { c, a ->
            PhoneTools.alarm(c, a.optInt("hour", -1), a.optInt("minute", 0), a.optString("label", "JARVIS alarm"))
        },
        ToolSpec("set_timer", """{"seconds":300,"label":"text"}""", false) { c, a ->
            PhoneTools.timer(c, a.optInt("seconds", 0), a.optString("label", "JARVIS timer"))
        },
        ToolSpec("volume", """{"action":"up|down|max|mute|set","percent":0-100}""", false) { c, a ->
            PhoneTools.volume(c, a.optString("action"), a.optInt("percent", 50))
        },
        ToolSpec("brightness", """{"percent":1-100}""", false) { c, a -> PhoneTools.brightness(c, a.optInt("percent", 50)) },
        ToolSpec("do_not_disturb", """{"on":true}""", true) { c, a -> PhoneTools.doNotDisturb(c, a.optBoolean("on", true)) },
        ToolSpec("open_settings", """{"target":"wifi|bluetooth|location|battery|sound|display|general"}""", false) { c, a ->
            PhoneTools.openSettings(c, a.optString("target", "general"))
        },
        ToolSpec("call", """{"target":"contact name or phone number"}""", true) { c, a -> PhoneTools.call(c, a.optString("target")) },
        ToolSpec("sms", """{"target":"contact name or number","message":"text"}""", true) { c, a ->
            PhoneTools.sms(c, a.optString("target"), a.optString("message"))
        },
        ToolSpec("calendar_event", """{"title":"text","start":"yyyy-MM-ddTHH:mm","end":"optional same format","description":"optional"}""", true) { c, a ->
            PhoneTools.calendar(c, a.optString("title", "Event"), a.optString("start"), a.optString("end"), a.optString("description"))
        },
        ToolSpec("read_notifications", "{}", false) { c, _ -> PhoneTools.readNotifications(c) },
        ToolSpec("battery", "{}", false) { c, _ -> ToolResult(DeviceInfoTool.battery(c)) },
        ToolSpec("time", "{}", false) { _, _ -> ToolResult(DeviceInfoTool.time()) },
        ToolSpec("remember", """{"text":"fact to remember"}""", false) { _, a ->
            val t = a.optString("text").trim()
            if (t.isBlank()) ToolResult("What should I remember?")
            else { onRemember(t); ToolResult("Okay, I'll remember that.") }
        },
        ToolSpec("forget_all", "{}", false) { _, _ -> onForgetAll(); ToolResult("I've cleared everything I remembered.") }
    )

    fun find(name: String): ToolSpec? = tools.firstOrNull { it.name == name }

    fun describeTools(): String = tools.joinToString("\n") { "- ${it.name} ${it.usage}" }

    /** Reads {"tool":..., "args":{...}, "say":...} out of an AI reply, or returns null for plain text. */
    fun parse(raw: String): ToolCall? {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val o = JSONObject(raw.substring(s, e + 1))
            val name = o.optString("tool")
            if (name.isBlank()) null else ToolCall(name, o.optJSONObject("args") ?: JSONObject(), o.optString("say"))
        } catch (ex: Exception) {
            null
        }
    }

    /** Simple commands handled on the phone itself without the AI (works offline). */
    fun tryLocal(input: String): ToolCall? {
        val t = input.lowercase().trim().removePrefix("jarvis").trim(' ', ',', '.', '!', '?')

        Regex("""timer for (\d+)\s*(second|sec|minute|min|hour)""").find(t)?.let {
            val n = it.groupValues[1].toInt()
            val secs = when (it.groupValues[2]) { "second", "sec" -> n; "minute", "min" -> n * 60; else -> n * 3600 }
            return ToolCall("set_timer", JSONObject().put("seconds", secs).put("label", "JARVIS timer"))
        }
        if (t.contains("volume") || t == "mute") {
            val action = when {
                t.contains("up") || t.contains("increase") || t.contains("raise") -> "up"
                t.contains("down") || t.contains("decrease") || t.contains("lower") -> "down"
                t.contains("max") || t.contains("full") -> "max"
                t.contains("mute") -> "mute"
                else -> null
            }
            if (action != null) return ToolCall("volume", JSONObject().put("action", action))
        }
        if (t.startsWith("remember that ") || t.startsWith("remember ")) {
            return ToolCall("remember", JSONObject().put("text", t.removePrefix("remember that ").removePrefix("remember ")))
        }
        if (t.contains("forget everything") || t.contains("clear your memory")) return ToolCall("forget_all", JSONObject())
        if (t.contains("flashlight") || t.contains("torch")) {
            return ToolCall("flashlight", JSONObject().put("on", !t.contains("off")))
        }
        if (t.contains("battery")) return ToolCall("battery", JSONObject())
        if (t.contains("what time") || t == "time") return ToolCall("time", JSONObject())
        val openPrefix = listOf("open ", "launch ", "start ").firstOrNull { t.startsWith(it) }
        if (openPrefix != null) {
            val name = t.removePrefix(openPrefix).removePrefix("the ").removeSuffix(" app")
            return ToolCall("open_app", JSONObject().put("name", name))
        }
        return null
    }
}

package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

/** Small translucent panel that appears over whatever app you are in. Opened from the notification or the tile. */
class VoiceOverlayActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OverlayScreen(onClose = { finish() }) }
    }
}

@Composable
fun OverlayScreen(onClose: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF3DDCFF))) {
        val vm: JarvisViewModel = viewModel()
        val ctx = LocalContext.current
        var started by remember { mutableStateOf(false) }
        PermissionHost(vm)

        val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) { started = true; vm.onMicTapped() } else onClose()
        }
        LaunchedEffect(Unit) {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) { started = true; vm.onMicTapped() } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        // close a couple of seconds after JARVIS finishes, unless it is waiting for your confirmation
        LaunchedEffect(vm.status, vm.pending, vm.permissionRequest, started) {
            if (started && vm.status == Status.IDLE && vm.pending == null && vm.permissionRequest == null) {
                delay(2500)
                onClose()
            }
        }

        val accent = accentFor(vm.status, vm.paused)
        val label = when (vm.status) {
            Status.LISTENING -> "LISTENING"
            Status.THINKING -> "PROCESSING"
            Status.SPEAKING -> "SPEAKING"
            Status.IDLE -> "STANDBY"
        }
        val lastUser = vm.messages.lastOrNull { it.fromUser }?.text
        val lastBot = vm.messages.lastOrNull { !it.fromUser }?.text ?: ""

        Box(
            Modifier.fillMaxSize().background(Color(0x66000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
        ) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)
                    .background(Color(0xFF050B14), RoundedCornerShape(24.dp)).padding(16.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Orb(vm.status, vm.level, accent, Modifier.fillMaxWidth().height(170.dp))
                Text(label, color = accent, fontSize = 12.sp, letterSpacing = 5.sp)
                Column(
                    Modifier.heightIn(max = 130.dp).padding(top = 8.dp).verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (lastUser != null) Text("\u201C$lastUser\u201D", color = Color(0xFF7C93AB), fontSize = 13.sp, textAlign = TextAlign.Center)
                    Text(lastBot, color = Color(0xFFE8F4FF), fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
                }
                ConfirmCard(vm)
            }
        }
    }
}
